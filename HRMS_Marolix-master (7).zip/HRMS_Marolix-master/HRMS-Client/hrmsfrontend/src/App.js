import React from 'react';
import LandingPage from './components/LandingPage/LandingPage';
import Common from './components/Common/Common';

const App = () => {
  return (
    <div className="App">
       {/* <LandingPage /> */}
      <Common/>
    </div>
  );
};

export default App;
